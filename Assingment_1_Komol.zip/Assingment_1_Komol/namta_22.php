<?php 

 for ($i=22; $i <23 ; $i++) { 
 	for ($j=1; $j <21 ; $j++) { 
 		echo $i." X ".$j." = ".($j*$i)."<br>";
 	}
 }


 ?>


 