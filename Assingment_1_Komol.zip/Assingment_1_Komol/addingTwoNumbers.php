<?php 
	
	$loan = 100;
	$profit = 200;



	function addNumbers($num1,$num2){

		$total = $num1+$num2;
		
		return $total;

	}
	
	$result = addNumbers($loan,$profit);

	print($result) ;

 ?>