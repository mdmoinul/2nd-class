<?php 
	echo "Odd nubers from 01 to 100 are shown below"."<br>";

	for ($i=1; $i <=20 ; $i+=2) { 

		echo $i."  ";


	}

	echo "<br>";

	echo "and even numbers are:"."<br>";

	for ($j=2; $j <=20 ; $j+=2) {
		echo $j. "  ";
	}

	
 ?>