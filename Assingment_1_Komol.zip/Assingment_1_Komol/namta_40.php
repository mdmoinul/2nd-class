<?php 

	for ($i=40; $i <41 ; $i++) { 
		for ($j=1; $j < 21 ; $j++) { 
			
			echo $i." X ".$j." = ".($i*$j)."<br>";
		}
	}

 ?>