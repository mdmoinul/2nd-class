

<!-- Find even numbers between 1 to 20 -->


<?php 

	for ($i=0; $i < ; $i++) { 
		# code...
	}


?>