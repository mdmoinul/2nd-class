

<!-- Substract Two Numbers -->

<?php 

function substractNumbers($number1,$number2){

	$result = $number1-$number2;

	return $result;

}

$comilla = 600;
$narsingdi = 500;

$minus = substractNumbers($comilla,$narsingdi);

print($minus);


 ?>

