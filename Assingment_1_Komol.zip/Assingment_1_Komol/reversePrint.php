<?php 


echo "ReversePrint"."<br>"; 


for ($i=30; $i >=0 ; $i--) { 
	echo "<strong>$i</strong>"."<br>";
}


?>
